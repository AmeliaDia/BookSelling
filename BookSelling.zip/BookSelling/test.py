from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import urllib.request

url = "https://doc-merge.com/"


s = Service('/usr/local/bin/chromedriver')
driver = webdriver.Chrome(service=s)
driver.get(url)

picture = driver.find_element(By.CLASS_NAME, "navbar-brand mb-0 h1").get_attribute("src")
#problem
urllib.request.urlretrieve(picture, "/home/lhcywww/AmeliaThrift/BookSelling/bulkUpload/Covers/"+"test"+".jpg")
print('end')
