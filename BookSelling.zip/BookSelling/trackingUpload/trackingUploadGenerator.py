import pandas as pd

#get dataframes
templateAddress = "/home/lhcywww/AmeliaThrift/BookSelling/trackingUpload/shippingTemplate.csv"
templateDf = pd.read_csv(templateAddress, dtype=str)
soldFileAddress = "/home/lhcywww/AmeliaThrift/BookSelling/SoldFIles/soldList.csv"
soldFileDf = pd.read_csv(soldFileAddress, dtype=str)

#extract data to templateDf
templateDf["Order Number"] = soldFileDf["Order Number"]
templateDf["Item Number"] = soldFileDf["Item Number"]
templateDf["Transaction ID"] = soldFileDf["Transaction ID"]
templateDf["Item Title"] = soldFileDf["Item Title"]
templateDf["Tracking Number"] = ["None" for x in range(len(templateDf["Order Number"]))]
templateDf["Shipping Status"] = ["1" for x in range(len(templateDf["Order Number"]))]
templateDf["Shipping Carrier Used"] = ["USPS" for x in range(len(templateDf["Order Number"]))]

#overwrite original shipping template file
templateDf.to_csv("/home/lhcywww/AmeliaThrift/BookSelling/trackingUpload/shippingTemplate.csv",float_format="%.60f", index=False)
print("!!!!!!!                                     !!!!!!!!!!!!!!!!\n!!!!!!                                  !!!!!!!!!!!!!\n!!!!!!Remember to copy & paste the Tracking Number!!!!!!!!\n!!!!!!!!!!!!                              !!!!!!!!!!!!!\n!!!!!!                               !!!!!!!!!")
