import difflib
import pandas as pd
import openpyxl

#open needed files
#find titles of sold items
soldFileDf = pd.read_csv('/home/lhcywww/AmeliaThrift/BookSelling/SoldFIles/soldList.csv')

#get needed lists
titles = soldFileDf["Item Title"].tolist() #store sold item titles
titles = [x for x in titles if x == x]
soldTitles = []
soldLocations = []
soldCustomLabels = soldFileDf["Custom Label"].tolist()
lenSoldTitles = len(titles)

#update DVDs in storage and count file by sold titles
for soldItemIndex in range(lenSoldTitles):
    print(soldItemIndex,'/',lenSoldTitles)
    soldTitles.append(titles[soldItemIndex])
    if (soldCustomLabels[soldItemIndex] == soldCustomLabels[soldItemIndex]) and  len(soldCustomLabels[soldItemIndex]) > 7:
        try:
            #find data
            #read new TitleStorage file everytime
            storageTitleAddress = '/home/lhcywww/AmeliaThrift/BookSelling/Storage/StorageTitle.xlsx'
            storage = pd.read_excel("/home/lhcywww/AmeliaThrift/BookSelling/Storage/StorageTitle.xlsx")
            storedLocations = storage["Location"].tolist()
            storedType = storage["Type"].tolist()

            #find the storedItemIndex by the same customLabel
            storedCustomLabel = storage["Custom Label"].tolist()
            storedItemIndex = storedCustomLabel.index(soldCustomLabels[soldItemIndex])
            #find & store the item location
            itemLocation = storedLocations[storedItemIndex]
            soldLocations.append(itemLocation)
            #find sold Type
            soldType = storedType[storedItemIndex]

            #delete the sold item's row in storageTitle file
            storageTitleFile = openpyxl.load_workbook(storageTitleAddress)
            sheet = storageTitleFile['Sheet1']
            sheet.delete_rows(int(storedItemIndex + 2))
            storageTitleFile.save(storageTitleAddress)

            #update storageCount Dataframe
            storageCount = pd.read_excel("/home/lhcywww/AmeliaThrift/BookSelling/Storage/StorageCount.xlsx",dtype=str)
            countLocations = storageCount["Location"].tolist()
            countRowIndex = countLocations.index(itemLocation)
            if soldType == "b":
                storageCount.loc[countRowIndex][1] = int(storageCount.loc[countRowIndex][1]) - 2
                storageCount.loc[countRowIndex][3] = int(storageCount.loc[countRowIndex][3]) - 2
                storageCount.loc[countRowIndex][4] = int(storageCount.loc[countRowIndex][4]) + 2
            else:
                storageCount.loc[countRowIndex][2] = int(storageCount.loc[countRowIndex][2]) - 1
                storageCount.loc[countRowIndex][3] = int(storageCount.loc[countRowIndex][3]) - 1
                storageCount.loc[countRowIndex][4] = int(storageCount.loc[countRowIndex][4]) + 1

            #Overwrite storageCount File
            countWriter = pd.ExcelWriter("/home/lhcywww/AmeliaThrift/BookSelling/Storage/StorageCount.xlsx", engine='xlsxwriter')
            storageCount.to_excel(countWriter, sheet_name='Sheet1', index=False)
            countWriter.save()
        except:
            soldLocations.append("Title not found")
    else:
        soldLocations.append("Manually check & delete")

#write title-locations to a new csv file named "soldLocations.xlsx"
soldLocationList = {"Title": soldTitles, "Location": soldLocations}
soldDf = pd.DataFrame(soldLocationList)
soldLocationsWriter = pd.ExcelWriter("/home/lhcywww/AmeliaThrift/BookSelling/SoldFIles/soldLocations.xlsx", engine='xlsxwriter')
soldDf.to_excel(soldLocationsWriter, sheet_name='Sheet1', index=False)
soldLocationsWriter.save()
