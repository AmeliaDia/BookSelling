import pandas as pd
import requests
from bs4 import BeautifulSoup
import re
import time
import xlsxwriter

#Read Storage file
#Total = 20/file, book = 2, dvd = 1
storageAddress = "/home/lhcywww/AmeliaThrift/BookSelling/Storage/StorageTitle.xlsx"
storage = pd.read_excel(storageAddress, dtype=str)
storageCount = pd.read_excel("/home/lhcywww/AmeliaThrift/BookSelling/Storage/StorageCount.xlsx",dtype=str)
locations = storageCount["Location"].tolist()
available = storageCount["Available"].tolist()
availableDisc = {} #location:availableAmount
for n in range(len(locations)):
    availableDisc[locations[n]] = available[n]

#Read isbns
fileAddress = "/home/lhcywww/AmeliaThrift/BookSelling/Raw-ISBN/ISBN.xls"#scanned isbn file
isbn = pd.read_excel(fileAddress, dtype = str)["Barcode:"]
type = pd.read_excel(fileAddress)["Item:"].tolist()
isbn = isbn.tolist() #isbn = all scanned isbns
typeDisc = {} #isbn:type(book or dvd)
for n in range(len(isbn)):
    typeDisc[isbn[n]] = type[n]
titleDisc = {} #disc storage {isbn:title}
count = 1
length = len(isbn)

#Get titles by isbn from upcitemdb.com
for unit in isbn:
    URL = "https://www.upcitemdb.com/upc/" + unit
    page = requests.get(URL)
    soup = BeautifulSoup(page.content, "html.parser")
    try:
        title = soup.find('span', {'class' : 'destxt'}).text
        titleDisc[unit] = title
    except:
        titleDisc[unit] = "**Title not found**"
    print(count,'/', length,',', unit, titleDisc[unit])
    count = count + 1
    time.sleep(4)

#Find storage locations
locationDisc={}#isbn:location
for unitIsbn in isbn:
    type = typeDisc[unitIsbn]
    weight = 0
    if type == 'b':
        weight = 2
    else:
        weight = 1
    for l in range(len(locations)):
        if int(availableDisc[locations[l]]) >= weight:
            locationDisc[unitIsbn] = locations[l]
            #change the book/dvd, total, and available number at that location line
            if type == 'b':
                storageCount.loc[l,'Book'] = int(storageCount.loc[l,'Book']) + 2
                storageCount.loc[l,'Total'] = int(storageCount.loc[l,'Total']) + 2
                storageCount.loc[l,'Available'] = int(storageCount.loc[l,'Available']) - 2
                availableDisc[locations[l]] = int(availableDisc[locations[l]]) - 2
            else:
                storageCount.loc[l,'DVD/CD'] = int(storageCount.loc[l,'DVD/CD']) + 1
                storageCount.loc[l,'Total'] = int(storageCount.loc[l,'Total']) + 1
                storageCount.loc[l,'Available'] = int(storageCount.loc[l,'Available']) - 1
                availableDisc[locations[l]] = int(availableDisc[locations[l]]) - 1
            break

#overwrite the original StorageCount file after searching
countWriter = pd.ExcelWriter("/home/lhcywww/AmeliaThrift/BookSelling/Storage/StorageCount.xlsx", engine='xlsxwriter')
storageCount.to_excel(countWriter, sheet_name='Sheet1', index=False)
countWriter.save()

#Add new units to the StoargeTitle file
#Location, ISBN, Title, Type
newUnits = pd.DataFrame()
newUnits["ISBN"] = isbn
newUnits["Location"] = locationDisc.values()
newUnits["Title"] = titleDisc.values()
newUnits["Type"] = typeDisc.values()
storage = storage.append(newUnits, ignore_index=True, sort=False)
storageWriter = pd.ExcelWriter("/home/lhcywww/AmeliaThrift/BookSelling/Storage/StorageTitle.xlsx", engine='xlsxwriter')
storage.to_excel(storageWriter, sheet_name='Sheet1', index=False)
storageWriter.save()
