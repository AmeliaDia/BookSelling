import datetime
from pathlib import Path
from docxtpl import DocxTemplate
import pandas as pd
import math

base_dir = "/home/lhcywww/AmeliaThrift/BookSelling/ShippingLabels"
word_template_path = "/home/lhcywww/AmeliaThrift/BookSelling/ShippingLabels/template.docx"
soldListDf = pd.read_csv("/home/lhcywww/AmeliaThrift/BookSelling/SoldFIles/soldList.csv")
itemTitles = soldListDf["Item Title"].tolist()
itemTitles = [x for x in itemTitles if str(x) != 'nan']
skus = []
for itemTitle in itemTitles:
    if itemTitle == itemTitle:
        sku = ''.join(itemTitle.split(' '))[:6][::-1]
        skus.append(sku)
        buyerName = soldListDf["Ship To Name"].tolist()
        buyerName = [x for x in buyerName if str(x) != 'nan']
    context = {
        "Buyer_Name": buyerName,
        "Buyer_Address_1": soldListDf["Ship To Address 1"].tolist(),
        "Buyer_Address_2": soldListDf["Ship To Address 2"].tolist(),
        "Buyer_City": soldListDf["Ship To City"].tolist(),
        "Buyer_State": soldListDf["Ship To State"].tolist(),
        "Buyer_Zip": soldListDf["Ship To Zip"].tolist(),
        "Skus": skus
    }
for count, item in enumerate(context["Buyer_Address_2"]):
    if item != item:
        context["Buyer_Address_2"][count] = " "
amount = len(context["Buyer_Name"])
for index in range(amount):
    info = {
    "Buyer_Name": context["Buyer_Name"][index],
    "Buyer_Address_1": context["Buyer_Address_1"][index],
    "Buyer_Address_2": context["Buyer_Address_2"][index],
    "Buyer_City": context["Buyer_City"][index],
    "Buyer_State": context["Buyer_State"][index],
    "Buyer_Zip": context["Buyer_Zip"][index],
    "Skus": context["Skus"][index],
    "index": index
    }
    doc = DocxTemplate(word_template_path)
    doc.render(info)
    doc.save("/home/lhcywww/AmeliaThrift/BookSelling/ShippingLabels/ReadyLabels/"+str(index)+"_"+str(' '.join(itemTitles[index].replace("/"," ").split(" ")[:3]))+".docx")
