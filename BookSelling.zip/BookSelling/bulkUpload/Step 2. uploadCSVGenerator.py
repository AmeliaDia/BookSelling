#!/usr/bin/env python3

import pandas as pd

templateAddress = "/home/lhcywww/AmeliaThrift/BookSelling/bulkUpload/UploadTemplate.csv"
templateDf = pd.read_csv(templateAddress, dtype=str)
storageAddress = "/home/lhcywww/AmeliaThrift/BookSelling/Storage/StorageTitle.xlsx"
storageDf = pd.read_excel(storageAddress, dtype=str)

#!!!This part needs to be updated everytime!!!
print("Enter the startingLine")
s = input()
startingLine = int(s)
print("Enter the endingLine")
e = input()
endingLine = int(e)
#!!!This part needs to be updated everytime!!!
startingLine = startingLine - 2
endingLine = endingLine - 2
col0 = []
warnings = []

for currentLine in range(startingLine, endingLine + 1):
    col0.append("Add")
templateDf["*Action(SiteID=US|Country=US|Currency=USD|Version=1193|CC=UTF-8)"] = col0

for currentLine in range(startingLine, endingLine + 1):
    #get info of the current line
    title = storageDf.loc[currentLine][2]
    if (len(title) > 65):
        warnings.append(currentLine-startingLine+2)
    customLabel = storageDf.loc[currentLine][4]
    picURL = "https://ebaycoverphotos.s3.amazonaws.com/" + str(customLabel) + ".jpg"
    description = "<p style=\"color:red;font-family:verdana;text-align:center;font-size:160%;\">Please contact me first before leaving a negative feedback.</p><br><p style=\"color:red;font-family:verdana;text-align:center;font-size:160%;\">I am afraid I don't have time to test all DVDs. <br>If the DVD(s) you receive are not playable, I will issue a full refund or send a replacement.</p><br>Every DVD comes with a case. For some books or dvds, the cover will be different from the ebay default picture, or the insert artwork is lost. <br>Please message me if you want more pictures and details. <br>I don't normally accept returns. However, if there is any issue, please contact me first. <br>I will try my best to work out a reasonable solution. <br>I am not responsible for any losses and/or damages that may occur during shipping. <br>Shipping is FREE to any address in USA. Handling time is 1 - 3 business days. Shipping time is from M-F. Please feel free to contact me with any question. <br>Do not hesitate to view other items I have in my store! Thank you for looking and happy shopping!"
    #write upload csv info of current line

    templateIndex = currentLine - startingLine
    templateDf.loc[templateIndex][0] = "Add"
    templateDf.loc[templateIndex][1] = customLabel
    templateDf.loc[templateIndex][2] = "617"
    templateDf.loc[templateIndex][4] = title
    templateDf.loc[templateIndex][8] = "5000"
    templateDf.loc[templateIndex][9] = "DVD"
    templateDf.loc[templateIndex][10] = title
    templateDf.loc[templateIndex][19] = "English"
    templateDf.loc[templateIndex][38] = picURL
    templateDf.loc[templateIndex][40] = description
    templateDf.loc[templateIndex][41] = "FixedPrice"
    templateDf.loc[templateIndex][42] = "GTC"
    templateDf.loc[templateIndex][43] = "3"
    templateDf.loc[templateIndex][45] = "1"
    templateDf.loc[templateIndex][56] = "3"
    templateDf.loc[templateIndex][64] = "DVD Shipping"
    templateDf.loc[templateIndex][65] = "No returns accepted,International:No returns"
    templateDf.loc[templateIndex][66] = "eBay Payments:Immediate pay"
    templateDf.loc[templateIndex][69] = "21218"
print("title length error: ", warnings)
#Overwrite templateDf
templateDf.to_csv("/home/lhcywww/AmeliaThrift/BookSelling/bulkUpload/UploadTemplate.csv", index=False)
print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!Remember to empty the template file after uploading!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
