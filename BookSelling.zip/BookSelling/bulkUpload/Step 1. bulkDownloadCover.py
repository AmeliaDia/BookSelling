import requests
from bs4 import BeautifulSoup
import re
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import urllib.request
from datetime import date
import random
import time
import xlsxwriter

#MUST CHANGE STARTING LINE TO INDICATE WHERE TO START DOWNLOADINGF PICTURES!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
print("Enter the startingLine")
s = input()
startingLine = int(s)
print("Enter the endingLine")
e = input()
endingLine = int(e)
#Endingline Too !!!!!!!!!!!!!
startingLine = startingLine - 2
endingLine = endingLine - 2

#Read ISBN into lists
storageAddress = "/home/lhcywww/AmeliaThrift/BookSelling/Storage/StorageTitle.xlsx"
storage = pd.read_excel(storageAddress, dtype=str)
ISBNs = storage["ISBN"].tolist()
SKUs = []

#Get cover from www.barcodelookup.com + update Custom Label
today = date.today()
date = today.strftime("%d%b%Y")

for i in range(startingLine, endingLine + 1):
    print(i,'/',endingLine)
    tail = str(random.randint(10000, 99999)) + '_' + str(storage["Location"].loc[i])
    SKU = date+'_'+str(i+2)+'_'+tail

    #update SKU
    storage.iloc[i]["Custom Label"] = SKU
    skuWriter = pd.ExcelWriter("/home/lhcywww/AmeliaThrift/BookSelling/Storage/StorageTitle.xlsx", engine='xlsxwriter')
    storage.to_excel(skuWriter, sheet_name='Sheet1', index=False)
    skuWriter.save()

    #Get CoverPic
    ISBN = ISBNs[i]
    URL = "https://www.barcodelookup.com/" + str(ISBN)
    failPicURL = "https://ebayhostingtest.s3.amazonaws.com/download.png"

    s = Service('/usr/local/bin/chromedriver')
    driver = webdriver.Chrome(service=s)
    driver.get(URL)
    time.sleep(4)
    try:
        title = driver.find_element(By.TAG_NAME, 'h4').text
        xpath = '//*[@alt="'+title+'"]'
        picture = driver.find_element(By.XPATH, xpath).get_attribute("src")
        urllib.request.urlretrieve(picture, "/home/lhcywww/AmeliaThrift/BookSelling/bulkUpload/Covers/"+SKU+".jpg")

    except:
        urllib.request.urlretrieve(failPicURL, "/home/lhcywww/AmeliaThrift/BookSelling/bulkUpload/Covers/"+SKU+".jpg")
    driver.close()
print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!Remember to enlarge covers and upload to Amazon first!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
